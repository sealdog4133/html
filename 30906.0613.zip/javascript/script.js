$('.navi>li').mouseover(function(){
    $(this).children('.submenu').stop().slideDown()
});
$('.navi>li').mouseout(function(){
    $(this).children('.submenu').stop().slideUp()
});
setInterval(function(){
    $('.slidelist').delay(1000);
    $('.slidelist').animate({marginTop:-350});
    $('.slidelist').delay(1000);
    $('.slidelist').animate({marginTop:-700});
    $('.slidelist').delay(1000);
    $('.slidelist').animate({marginTop:0});
})
$('.c1>li>a').click(function(){
    $(this).parent().addClass('active')
    .siblings()
    .removeClass('active');
});

$('.notice li:first').click(function(){
    $('#modal').addClass('active');
});
$('.btn').click(function(){
    $('#modal').removeClass('active');
});