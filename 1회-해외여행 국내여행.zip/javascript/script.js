$(function(){
    $(".gong").on("click",function(){
        $(".bang").hide();
        $(".gong_bang").show();
        // 선택시 회색에서 흰색으로 바뀌는 거
        $(".galley").css("background","#ccc");
        $(".gong").css("background","white");
    })
    $(".galley").on("click",function(){
        $(".bang").hide();
        $(".galley_bang").show();
        $(".galley").css("background","white");
        $(".gong").css("background","#ccc");
    })
})