$('.main>li').mouseover(function(){
    $(this).children('.submenu').stop().slideDown();
})
$('.main>li').mouseout(function(){
    $(this).children('.submenu').stop().slideUp();
})

setInterval(function(){
    $('.slidelist').delay(3000);
    $('.slidelist').animate({marginLeft:-1200})
    $('.slidelist').delay(3000);
    $('.slidelist').animate({marginLeft:-2400})
    $('.slidelist').delay(3000);
    $('.slidelist').animate({marginLeft: 0})
    $('.slidelist').delay(3000);

})

$('.tabmenu>li>a').click(function(){
    $(this).parent().addClass('active')
    .siblings().removeClass('active');
    return false;
});