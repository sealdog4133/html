$('.main > li').mouseover(function(){
    $('.submenu').stop().slideDown(200);
});
$('.main > li').mouseout(function(){
    $('.submenu').stop().slideUp(200);
});

setInterval(function(){
    $('.slidelist').delay(2000);
    $('.slidelist').animate({marginLeft: -1000});
    $('.slidelist').delay(2000);
    $('.slidelist').animate({marginLeft: -2000});
    $('.slidelist').delay(2000);
    $('.slidelist').animate({marginLeft: -3000});
    $('.slidelist').delay(2000);
    $('.slidelist').animate({marginLeft: 0});
})

$('.tabmenu>li>a').click(function(){
    $(this).parent().addClass('active')
    .siblings().removeClass('active');
    return false
});

$('.tabmenu li:first').click(function(){
    $('#modal').addClass('active');
})
$('.btn').click(function(){
    $('#modal').removeClass('active');
})