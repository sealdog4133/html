$('.navi>li').mouseover(function(){
    $('.navi>li').children('.submenu').stop().slideDown()
});
$('.navi>li').mouseout(function(){
    $('.navi>li').children('.submenu').stop().slideUp()
});